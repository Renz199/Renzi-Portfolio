import React, { useState } from "react";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Mail, Phone, FileDown, Facebook, Linkedin } from "lucide-react";
import { Carousel } from "@/components/ui/carousel";

export default function Portfolio() {
  const fade = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  };

  const [darkMode, setDarkMode] = useState(false);

  return (
    <div className={`${darkMode ? "bg-gray-900 text-gray-100" : "bg-white text-gray-900"} min-h-screen font-sans transition-all`}>
      <div className="flex justify-end p-4">
        <Button onClick={() => setDarkMode(!darkMode)} className="rounded-full px-4">
          {darkMode ? "Light Mode" : "Dark Mode"}
        </Button>
      </div>

      <section className="w-full py-28 border-b bg-gradient-to-br from-gray-100 to-gray-300 dark:from-gray-800 dark:to-gray-700 relative overflow-hidden">
        <div className="absolute inset-0 opacity-20 bg-[radial-gradient(circle_at_top_left,white,transparent_70%)]"></div>
        <motion.div initial="hidden" animate="show" variants={fade} className="max-w-4xl mx-auto text-center px-6 relative">
          <img src="https://via.placeholder.com/200" alt="Profile" className="w-40 h-40 object-cover rounded-full mx-auto mb-6 shadow-xl" />
          <h1 className="text-5xl font-semibold tracking-tight mb-3">Renzi Ralph Gunita</h1>
          <p className="text-lg opacity-80 max-w-2xl mx-auto">
            Virtual Assistant • Customer Support Specialist • Technical Support • Executive Assistant
          </p>
          <div className="flex justify-center gap-4 mt-6">
            <Button className="rounded-full px-6">
              <FileDown className="w-4 h-4 mr-2" /> Download Resume
            </Button>
          </div>
        </motion.div>
      </section>

      <section className="max-w-4xl mx-auto py-20 px-6">
        <motion.div initial="hidden" whileInView="show" variants={fade}>
          <h2 className="text-3xl font-semibold mb-4">About Me</h2>
          <p className="opacity-80 leading-relaxed">
            With over 4 years of experience in executive assistance, customer service, and technical support,
            I specialize in helping businesses stay organized, efficient, and customer-focused.
          </p>
        </motion.div>
      </section>

      <section className="bg-gray-50 dark:bg-gray-800 py-20 border-y">
        <div className="max-w-5xl mx-auto px-6">
          <h2 className="text-3xl font-semibold mb-10">Projects & Case Studies</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {[1,2,3].map((p)=>(
              <motion.div key={p} initial="hidden" whileInView="show" variants={fade}>
                <Card className="rounded-xl shadow-sm">
                  <CardContent className="p-6">
                    <div className="h-32 bg-gray-200 dark:bg-gray-700 rounded mb-4"></div>
                    <h3 className="text-lg font-medium mb-2">Project Title {p}</h3>
                    <p className="opacity-70 text-sm">A short description of the project.</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-6">
        <div className="max-w-5xl mx-auto grid gap-10">
          <h2 className="text-3xl font-semibold mb-4">Work Experience</h2>
        </div>
      </section>

      <section className="bg-gray-50 dark:bg-gray-800 py-20 border-y">
        <div className="max-w-5xl mx-auto px-6">
          <h2 className="text-3xl font-semibold mb-10">Testimonials</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {[1,2,3].map((t)=>(
              <motion.div key={t} initial="hidden" whileInView="show" variants={fade}>
                <Card className="rounded-xl shadow-sm">
                  <CardContent className="p-6">
                    <div className="w-16 h-16 rounded-full bg-gray-200 dark:bg-gray-600 mb-4"></div>
                    <p className="italic opacity-80 mb-3">“Renzi is highly reliable and always delivers.”</p>
                    <p className="font-medium">Client Name</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="max-w-4xl mx-auto py-20 px-6">
        <h2 className="text-3xl font-semibold mb-10">Gallery</h2>
        <Carousel>
          {[1,2,3].map((i)=>(
            <div key={i} className="h-64 bg-gray-200 dark:bg-gray-700 rounded-xl"></div>
          ))}
        </Carousel>
      </section>

      <section className="bg-gray-900 text-gray-100 py-20">
        <div className="max-w-4xl mx-auto text-center px-6">
          <h2 className="text-3xl font-semibold mb-4">Let’s Work Together</h2>
          <p className="opacity-80 mb-6">I'm available for remote or long-term roles. Reach out anytime!</p>
          <div className="flex justify-center gap-6 mb-8">
            <div className="flex flex-col items-center">
              <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=https://your-portfolio-link.com" className="w-36 h-36 rounded-lg shadow-lg"/>
              <p className="mt-2 text-sm opacity-70">Scan to view my website</p>
            </div>
          </div>
          <div className="flex justify-center gap-6 text-xl">
            <Facebook />
            <Linkedin />
            <Mail />
          </div>
        </div>
      </section>
    </div>
  );
}
